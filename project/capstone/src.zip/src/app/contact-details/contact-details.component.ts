import { Component } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.css']
})
export class ContactDetailsComponent {
  profileForm = this.fb.group({
    contactName: ['', Validators.required],
    contactJobTitle: ['', Validators.required],
    contactEmail: ['', Validators.required],
    contactPhone: ['', Validators.required],
    contactAddress: ['', Validators.required],
    contactProjectTitle: ['', Validators.required],
    contactDescProject: ['', Validators.required],
    contactTechSkills: ['', Validators.required],
  });

  constructor(private fb: FormBuilder) { }

  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.warn(this.profileForm.value);
  }
}
